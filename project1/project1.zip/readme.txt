1.  Chance Cardona, ccardona@mymail.mines.edu, 10728053
2.  Python 3
3.  Windows 10 and ArchLinux
4.  Code is structured so it can be used as a module
    Classes include: Graph()
    Functions include: Dijkstra()
    I am using Dijkstra's method to solve the problem.
    Note: I wanted to use heapq or PriorityQueue but python doesn't support
    a priorityqueue with changeable priority (that you won't need to
    install) so I went with the Set datastructure.
5.  python3 find_route.py input_filename from_city to_city
        if python3 gives you permission denied use python
        All modules I use are built-in so you shouldn't have any problems.
