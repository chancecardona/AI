1. Chance Cardona, 10728053
2. Python 3.8.1 was used for this.
3. The code is structured as such:
    The main file is maxconnect4.py which handles input and calls game
    functions.
    The MaxConnect4Game.py is the actual connect4game.
    minimax.py is the actual minimax algorithm and the evaluation function.
4. python3 maxconnect4.py interactive input1.txt human-next 8
    Is an example of how to run. The code works well up to depth 11,
    but it works BEST at depth 8. This would be fixed if I had time
    to include the full Evaluation Function and could restructure
    the board further to allow better Point calculations for more depth,
    but alas I'm out of time.

    It works exactly as specified in the assignment so you shouldn't have
    any troubles with it as long as you're in python3.
